# JagTheBlue.github.io
Github homepage for JTB.

This is a created website where I can express the reality of my world.  I remain nameless so as to experience the freedom of not         being attached to a persona with both percieved and false expectations from the world and from myself.  I would humbly request           that those of you who do know my identity would keep it to yourselves.  It is my hope that through my honest expression of               pain, frustration, and victories that it would help others to articulate and come to terms with their own struggles and feel a           sense of support that they are not alone in the fight.
      
Our passion can lead us down some dark roads.  Thinking about offing yourself? Call this hotline first before you do anything             else.  
        <a href="https://suicidepreventionlifeline.org/"><em>1-800-273-8255</em></a>
 
 If you're still here reading this, thanks for your interest.  It means a lot to me.  I am just learning how to code with HTML           and CSS, so I apologize for this very elementary website.  I hope to delve into java next.
 
